from hashlib import new
from operator import ne
import os
import glob
from re import S
from zipfile import ZipFile
import zipfile
import shutil


def del_of_files(del_list_of_files):
    for f in del_list_of_files:
        os.remove(f)


def unzip_of_files(latest_file, destination_folder):
    with zipfile.ZipFile(latest_file, 'r') as zip_object: #unzipping the file and placing the content to the destination directory
        zip_object.extractall(destination_folder)

        sql_file = os.listdir(destination_folder)[0]
        
        return(sql_file)
        

def new_manifest_file(latest_file_split, stage3_manifest_tenants, sql_file):
    manifest_file = "post-release-hf/" + sql_file
    new_manifest_file = open(os.path.join(stage3_manifest_tenants+ 'stage3_manifest_tenants'), "w")
    new_manifest_file.write(manifest_file)
    new_manifest_file.close


def copy_of_files(latest_file_split, destination_folder):
    sql_file = shutil.copy('/tmp/software/db_patch_files/'+ latest_file_split, destination_folder)


def main():
    list_of_files = glob.glob('/tmp/software/db_patch_files/*')
    latest_file = max(list_of_files, key=os.path.getctime)#.split('/')[3] #Getting the recent/latest file in the directory
    latest_file_split = latest_file.split('/')[4]
    destination_folder = '/tmp/software/HMS_DatabaseUpgradeUtility/StackConf/HMS-3842/stage3/post-release-hf'
    stage3_manifest_tenants = '/tmp/software/HMS_DatabaseUpgradeUtility/StackConf/HMS-3842/stage3/'
    del_list_of_files = glob.glob(os.path.join(destination_folder, "*"))
    
    if latest_file.endswith('.zip'):
        del_of_files(del_list_of_files)
        sql_file = unzip_of_files(latest_file, destination_folder)
        new_manifest_file(latest_file_split, stage3_manifest_tenants, sql_file)
    else:
        del_of_files(del_list_of_files)
        copy_of_files(latest_file_split, destination_folder)
        new_manifest_file(latest_file_split, stage3_manifest_tenants, latest_file_split)
       


if __name__ == "__main__":
    main()