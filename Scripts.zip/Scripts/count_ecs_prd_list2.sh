#!/bin/bash
# jgooco
# Tuesday, May 15, 2018
# Modified Date: May 22, 2018
#####Script Starts Here#####
#set -vx
PRD_378="$1"
srvweb="hms-webhms-web-prduse1-HmsWebEcsService-JA65RQP6HJI4"
srvintg="hms-intghms-intg-prduse1-HmsIntgEcsService-9UQ0PPT1NCUE"
srvjob="hms-jobhms-job-prduse1-HmsJobEcsService-1EI3OFUUXREID"
srvwbe="hms-wbehms-wbe-prduse1-HmsWbeEcsService-STRR9UL1RUJV"
ncjob=`cat /tmp/job.txt`
ncintg=`cat /tmp/Intg.txt`
ncweb=`cat /tmp/Web.txt`
ncwbe=`cat /tmp/Wbe.txt`
prd="hms-prduse1-ecs-cluster"

########################Function that will assign desired tasks to 0##############

function countZERO {

	dcjob=`aws ecs describe-services --cluster $prd --services $srvjob | grep desiredCount | head -1 | cut -d ":" -f 2 | tr -d ","|tr -d " "`
	dcintg=`aws ecs describe-services --cluster $prd --services $srvintg | grep desiredCount | head -1 | cut -d ":" -f 2 | tr -d ","| tr -d " "`
	dcweb=`aws ecs describe-services --cluster $prd --services $srvweb | grep desiredCount | head -1 | cut -d ":" -f 2 | tr -d ","| tr -d " "`
	dcwbe=`aws ecs describe-services --cluster $prd --services $srvwbe | grep desiredCount | head -1 | cut -d ":" -f 2 | tr -d ","| tr -d " "`

	echo $dcjob > /tmp/Job.txt
	echo $dcintg > /tmp/Intg.txt
	echo $dcweb > /tmp/Web.txt 
	echo $dcwbe > /tmp/Wbe.txt

	for i in "${srvweb}" "${srvintg}" "${srvjob}" "${srvwbe}"; do

		aws ecs update-service --cluster $prd --service $i --desired-count 0
	
	done

}
######################Function that will assign the desired task to normal value##############

function countREVERT {
		

		aws ecs update-service --cluster $prd --service $srvweb --desired-count $ncweb
		aws ecs update-service --cluster $prd --service $srvintg --desired-count $ncintg
		aws ecs update-service --cluster $prd --service $srvjob --desired-count $ncjob
		aws ecs update-service --cluster $prd --service $srvwbe --desired-count $ncwbe        
}

	




if [ "$PRD_378" == "ZERO" ]; then
	countZERO

elif [ "$PRD_378" == "REVERT" ]; then
	countREVERT

else
	echo "Usage: $0 <ZERO|REVERT>"

fi





