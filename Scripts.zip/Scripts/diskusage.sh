for i in `cat 376.servers`; do echo $i; ssh -i ~/.ssh/keypairs/ncr-hmskey.pem ec2-user@$i df -h; done


