#!/bin/bash
#jgooco
# Monday, June 6, 2018

#Defining Variables

DDelay_378="$1"
ddwbe="arn:aws:elasticloadbalancing:us-east-1:026631811025:targetgroup/hms-wbe-tg/3f5abc2f4b46f580"
ddjob="arn:aws:elasticloadbalancing:us-east-1:026631811025:targetgroup/hms-job-tg/89e8071f5982fbef"
ddweb="arn:aws:elasticloadbalancing:us-east-1:026631811025:targetgroup/hms-web-tg/70457e6636c25a8e"
ddintg="arn:aws:elasticloadbalancing:us-east-1:026631811025:targetgroup/hms-intg-tg/46de5520b2ba68d2"
#profile="hms-prd"
#region="us-east-1"

#######Script Starts Here###########

function dd60 {

for i in "${ddwbe}" "${ddjob}" "${ddweb}" "${ddintg}"; do

aws elbv2 modify-target-group-attributes --target-group-arn $i --attributes Key=deregistration_delay.timeout_seconds,Value=60

done

}


function dd300  {

for i in "${ddwbe}" "${ddjob}" "${ddweb}" "${ddintg}"; do

aws elbv2 modify-target-group-attributes --target-group-arn $i --attributes Key=deregistration_delay.timeout_seconds,Value=300

done

}



if [ "$DDelay_378" == "60" ]; then
	dd60

elif [ "$DDelay_378" == "300" ]; then
	dd300

else
	echo "Usage: $0 <60|300>"

fi



